from django.http import HttpResponse

def panel_estudiante(request):
    return HttpResponse("Panel del Estudiante")
