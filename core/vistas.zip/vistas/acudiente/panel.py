from django.http import HttpResponse

def panel_acudiente(request):
    return HttpResponse("Panel del Acudiente")
