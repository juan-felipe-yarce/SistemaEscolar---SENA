def es_coordinador(user):
    return user.rol.nombre == 'Coordinador Académico'

